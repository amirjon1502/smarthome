package com.amirjon.smarthome

import android.content.Context

/** Simple settings storage. Keys are entered in the Settings dialog, never hard-coded. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("smarthome", Context.MODE_PRIVATE)

    var sinricKey: String
        get() = sp.getString("sinricKey", "") ?: ""
        set(v) = sp.edit().putString("sinricKey", v.trim()).apply()

    var claudeKey: String
        get() = sp.getString("claudeKey", "") ?: ""
        set(v) = sp.edit().putString("claudeKey", v.trim()).apply()

    var lightId: String
        get() = sp.getString("lightId", "6a74b2ee29c6be33428a287b") ?: ""
        set(v) = sp.edit().putString("lightId", v.trim()).apply()

    var ventId: String
        get() = sp.getString("ventId", "6afaf46c7d04ce9fd6516e9a") ?: ""
        set(v) = sp.edit().putString("ventId", v.trim()).apply()

    var tempId: String
        get() = sp.getString("tempId", "6a759b406ba33a80b9a45067") ?: ""
        set(v) = sp.edit().putString("tempId", v.trim()).apply()

    /** BCP-47 tag such as en-US, ru-RU, uz-UZ. Empty = phone's language. */
    var voiceLang: String
        get() = sp.getString("voiceLang", "") ?: ""
        set(v) = sp.edit().putString("voiceLang", v.trim()).apply()

    /** Keep listening after every answer (no tapping needed). */
    var handsFree: Boolean
        get() = sp.getBoolean("handsFree", false)
        set(v) = sp.edit().putBoolean("handsFree", v).apply()
}
