package com.amirjon.smarthome

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** What the assistant is allowed to do in the house. */
interface HomeActions {
    suspend fun setDevice(device: String, on: Boolean): String   // device = "light" | "vent"
    fun status(): String
}

/**
 * AI assistant. With a Claude API key it understands free-form requests (any language)
 * and calls the home tools. Without a key it falls back to simple keyword commands.
 */
class Assistant(private val prefs: Prefs, private val home: HomeActions) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val model = "claude-haiku-5-5"

    private val system = """
        You are the voice assistant of a smart home. You control a light and a ventilation fan
        (vent) and can read temperature and humidity. Use the tools to act; never claim you did
        something without calling the tool. Reply in the user's language, in one or two short
        sentences, because the answer is shown on a wall screen and read aloud.
    """.trimIndent()

    private val tools = JSONArray().put(
        JSONObject()
            .put("name", "control_device")
            .put("description", "Turn the light or the ventilation fan on or off.")
            .put("input_schema", JSONObject()
                .put("type", "object")
                .put("properties", JSONObject()
                    .put("device", JSONObject().put("type", "string").put("enum", JSONArray(listOf("light", "vent"))))
                    .put("state", JSONObject().put("type", "string").put("enum", JSONArray(listOf("on", "off")))))
                .put("required", JSONArray(listOf("device", "state"))))
    ).put(
        JSONObject()
            .put("name", "get_status")
            .put("description", "Get current temperature, humidity, and light/vent state.")
            .put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
    )

    suspend fun handle(text: String): String {
        if (prefs.claudeKey.isBlank()) return offline(text)
        return try {
            askClaude(text)
        } catch (e: Exception) {
            "AI unavailable (${e.message?.take(60)}). " + offline(text)
        }
    }

    // ---------- Claude with tool use ----------
    private suspend fun askClaude(text: String): String {
        val messages = JSONArray().put(
            JSONObject().put("role", "user").put("content", text)
        )
        repeat(4) {
            val resp = post(messages)
            val content = resp.getJSONArray("content")
            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().ifBlank { "Done." }
            }
            messages.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") != "tool_use") continue
                val input = b.getJSONObject("input")
                val out = when (b.getString("name")) {
                    "control_device" -> home.setDevice(
                        input.getString("device"), input.getString("state") == "on")
                    "get_status" -> home.status()
                    else -> "Unknown tool"
                }
                results.put(JSONObject()
                    .put("type", "tool_result")
                    .put("tool_use_id", b.getString("id"))
                    .put("content", out))
            }
            messages.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Done."
    }

    private suspend fun post(messages: JSONArray): JSONObject = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 512)
            .put("system", system)
            .put("tools", tools)
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", prefs.claudeKey)
            .header("anthropic-version", "2023-06-01")
            .post(body)
            .build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}")
            JSONObject(s)
        }
    }

    // ---------- Offline keyword fallback (English / Russian / Uzbek) ----------
    private suspend fun offline(text: String): String {
        val t = text.lowercase()
        val light = listOf("light", "lamp", "свет", "лампа", "chiroq", "yorug").any { t.contains(it) }
        val vent = listOf("vent", "fan", "вентил", "вытяж", "ventilyator", "shamollat").any { t.contains(it) }
        val off = listOf("off", "выкл", "погас", "o'chir", "ochir", "o‘chir").any { t.contains(it) }
        val on = listOf("on", "вкл", "зажг", "yoq", "yoqing").any { t.contains(it) }

        if (light || vent) {
            val state = when {
                off -> false
                on -> true
                else -> return "Say on or off."
            }
            val parts = mutableListOf<String>()
            if (light) parts += home.setDevice("light", state)
            if (vent) parts += home.setDevice("vent", state)
            return parts.joinToString(" ")
        }
        if (listOf("temp", "hum", "темпер", "влаж", "harorat", "namlik", "status").any { t.contains(it) })
            return home.status()
        return "I did not understand. Add a Claude API key in Settings for full AI."
    }
}
