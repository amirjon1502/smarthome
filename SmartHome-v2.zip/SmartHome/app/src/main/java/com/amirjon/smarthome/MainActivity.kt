package com.amirjon.smarthome

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.amirjon.smarthome.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), HomeActions, VoiceInput.Callback {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var sinric: SinricClient
    private lateinit var assistant: Assistant
    private lateinit var voice: VoiceInput
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())

    private var lightOn: Boolean? = null
    private var ventOn: Boolean? = null
    private var temp: Double? = null
    private var hum: Double? = null
    private var updated: String = ""

    private var busy = false          // assistant is thinking or speaking
    private var lastWasError = false
    private var resumed = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else Toast.makeText(this, "Microphone permission is needed for voice commands", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // ---- no screen timeout while the app is open (charger plugged in) ----
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        hideSystemBars()

        prefs = Prefs(this)
        sinric = SinricClient(prefs)
        assistant = Assistant(prefs, this)
        voice = VoiceInput(this, this)
        initTts()

        b.face.onTap = { toggleListening() }
        b.btnMic.setOnClickListener { toggleListening() }
        b.btnLight.setOnClickListener { toggle("light") }
        b.btnVent.setOnClickListener { toggle("vent") }
        b.btnSettings.setOnClickListener { showSettings() }
        b.btnSend.setOnClickListener { sendTyped() }
        b.etInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
        }

        if (prefs.sinricKey.isBlank()) showSettings()
        render()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ---- live connection runs only while the screen is visible ----
    override fun onStart() {
        super.onStart()
        resumed = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { loadInitial() }
                sinric.listen(
                    onStatus = { ok -> runOnUiThread { setConn(ok) } },
                    onEvent = { ev -> runOnUiThread { handleEvent(ev) } }
                )
            }
        }
        if (prefs.handsFree) scheduleListen(800)
    }

    override fun onStop() {
        resumed = false
        handler.removeCallbacksAndMessages(null)
        voice.stop()
        tts?.stop()
        busy = false
        b.face.level = 0f
        b.face.mode = FaceView.Mode.IDLE
        super.onStop()
    }

    private suspend fun loadInitial() {
        sinric.getDevice(prefs.tempId)?.let { applySensor(it) }
        sinric.getDevice(prefs.lightId)?.let { applyPower(prefs.lightId, it) }
        sinric.getDevice(prefs.ventId)?.let { applyPower(prefs.ventId, it) }
        render()
    }

    private fun handleEvent(ev: JSONObject) {
        val id = SinricClient.find(ev, "deviceId") as? String ?: return
        when (id) {
            prefs.tempId -> applySensor(ev)
            prefs.lightId, prefs.ventId -> applyPower(id, ev)
        }
        render()
    }

    private fun applySensor(node: Any) {
        val t = SinricClient.number(node, "temperature")
        val h = SinricClient.number(node, "humidity")
        if (t != null) temp = t
        if (h != null) hum = h
        if (t != null || h != null) updated = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    private fun applyPower(id: String, node: Any) {
        val s = (SinricClient.find(node, "state") as? String)
            ?: (SinricClient.find(node, "powerState") as? String) ?: return
        val on = s.equals("On", true)
        if (id == prefs.lightId) lightOn = on else ventOn = on
    }

    // ---- UI ----
    private fun setConn(ok: Boolean) {
        b.tvConn.text = if (ok) "● online" else "● offline"
        b.tvConn.setTextColor(if (ok) Color.parseColor("#3DD68C") else Color.parseColor("#E5484D"))
    }

    private fun render() {
        b.tvTemp.text = temp?.let { String.format(Locale.US, "%.1f°C", it) } ?: "--"
        b.tvHum.text = hum?.let { String.format(Locale.US, "%.0f%%", it) } ?: "--"
        b.tvUpdated.text = if (updated.isEmpty()) "Waiting for first reading… (sensor reports about once a minute)"
        else "Updated $updated"
        paint(b.btnLight, "Light", lightOn)
        paint(b.btnVent, "Vent", ventOn)
    }

    private fun paint(btn: Button, name: String, on: Boolean?) {
        btn.text = "$name · " + when (on) { true -> "ON"; false -> "OFF"; null -> "?" }
        btn.setBackgroundColor(if (on == true) Color.parseColor("#2F9E5B") else Color.parseColor("#2A323D"))
        btn.setTextColor(Color.WHITE)
    }

    private fun toggle(device: String) {
        val now = if (device == "light") lightOn else ventOn
        lifecycleScope.launch {
            val msg = setDevice(device, !(now ?: false))
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            if (msg.startsWith("Could not")) b.face.fail() else b.face.celebrate()
        }
    }

    // ---- text-to-speech ----
    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = if (prefs.voiceLang.isBlank()) Locale.getDefault()
                else Locale.forLanguageTag(prefs.voiceLang)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { runOnUiThread { finishTurn() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { runOnUiThread { finishTurn() } }
                })
            }
        }
    }

    // ---- voice: tap face / mic ----
    private fun toggleListening() {
        when {
            busy -> {                       // tapping while it talks = stop talking
                tts?.stop()
                busy = false
                b.face.mode = FaceView.Mode.IDLE
            }
            voice.active -> {
                voice.stop()
                b.face.level = 0f
                b.face.mode = FaceView.Mode.IDLE
                b.tvReply.text = "Stopped listening."
            }
            else -> startListening()
        }
    }

    private fun startListening() {
        if (busy || !resumed) return
        if (!voice.available()) {
            Toast.makeText(this, "Speech recognition is not available. Install/enable the Google app.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        b.face.mode = FaceView.Mode.LISTENING
        b.tvReply.text = "Listening…"
        voice.start(prefs.voiceLang)
    }

    private fun scheduleListen(delayMs: Long) {
        handler.postDelayed({
            if (prefs.handsFree && resumed && !busy && !voice.active) startListening()
        }, delayMs)
    }

    // VoiceInput.Callback
    override fun onLevel(level: Float) { b.face.level = level }

    override fun onPartial(text: String) { b.tvReply.text = "“$text”" }

    override fun onFinal(text: String) { runAssistant(text) }

    override fun onFail(code: Int) {
        b.face.level = 0f
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                b.face.mode = FaceView.Mode.IDLE
                if (prefs.handsFree) scheduleListen(400)
                else b.tvReply.text = "I didn't catch that. Tap me and try again."
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                b.face.mode = FaceView.Mode.IDLE
                scheduleListen(900)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else -> {
                b.face.fail()
                b.tvReply.text = "Voice error ($code). Check internet and the Google app."
                if (prefs.handsFree) scheduleListen(4000)
            }
        }
    }

    // ---- assistant ----
    private fun sendTyped() {
        val t = b.etInput.text.toString().trim()
        if (t.isEmpty()) return
        b.etInput.setText("")
        voice.stop()
        busy = false
        runAssistant(t)
    }

    private fun runAssistant(text: String) {
        busy = true
        b.face.level = 0f
        b.face.mode = FaceView.Mode.THINKING
        b.tvReply.text = "You: $text"
        lifecycleScope.launch {
            val reply = assistant.handle(text)
            lastWasError = reply.startsWith("Could not") || reply.startsWith("AI unavailable")
            b.tvReply.text = "You: $text\n\n$reply"
            if (ttsReady) {
                b.face.mode = FaceView.Mode.SPEAKING
                tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")
            } else {
                finishTurn()
            }
        }
    }

    private fun finishTurn() {
        busy = false
        if (lastWasError) b.face.fail() else b.face.celebrate()
        if (prefs.handsFree) scheduleListen(1600)
    }

    // ---- HomeActions (used by the assistant and the buttons) ----
    override suspend fun setDevice(device: String, on: Boolean): String {
        val id = if (device == "light") prefs.lightId else prefs.ventId
        val label = if (device == "light") "Light" else "Vent"
        val ok = sinric.setPower(id, on)
        return if (ok) {
            if (device == "light") lightOn = on else ventOn = on
            render()
            "$label turned ${if (on) "on" else "off"}."
        } else "Could not reach SinricPro. Check the API key and internet."
    }

    override fun status(): String {
        val t = temp?.let { String.format(Locale.US, "%.1f°C", it) } ?: "unknown"
        val h = hum?.let { String.format(Locale.US, "%.0f%%", it) } ?: "unknown"
        fun s(v: Boolean?) = when (v) { true -> "on"; false -> "off"; null -> "unknown" }
        return "Temperature $t, humidity $h, light ${s(lightOn)}, vent ${s(ventOn)}."
    }

    // ---- settings ----
    private fun showSettings() {
        fun field(label: String, value: String, secret: Boolean = false) = EditText(this).apply {
            hint = label
            setText(value)
            if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val key = field("SinricPro API key (Dashboard → Credentials)", prefs.sinricKey, true)
        val claude = field("Claude API key (optional, for AI)", prefs.claudeKey, true)
        val light = field("Light device ID", prefs.lightId)
        val vent = field("Vent device ID", prefs.ventId)
        val tempF = field("Temperature sensor device ID", prefs.tempId)
        val lang = field("Voice language (en-US, ru-RU, uz-UZ… blank = phone)", prefs.voiceLang)
        val hands = CheckBox(this).apply {
            text = "Hands-free: keep listening after every answer"
            isChecked = prefs.handsFree
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            listOf(key, claude, light, vent, tempF, lang, hands).forEach { addView(it) }
        }
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.sinricKey = key.text.toString()
                prefs.claudeKey = claude.text.toString()
                prefs.lightId = light.text.toString()
                prefs.ventId = vent.text.toString()
                prefs.tempId = tempF.text.toString()
                prefs.voiceLang = lang.text.toString()
                prefs.handsFree = hands.isChecked
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        voice.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
