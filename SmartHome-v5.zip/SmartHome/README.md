# Smart Home (Android 7.1+)

Wall-panel app for your ESP8266 + SinricPro setup.

- Screen never times out while the app is open (plug the charger in and leave it)
- Light and Vent buttons (SinricPro REST API)
- Live temperature and humidity (SinricPro event stream; the ESP sends a reading about once a minute)
- AI assistant: mic or typed commands, in any language (needs a Claude API key; without one, simple keyword commands work in English/Russian/Uzbek)

## Build the APK
1. Install Android Studio and open this folder (`SmartHome`). Let it sync Gradle.
2. Build > Build APK(s). The file appears in `app/build/outputs/apk/debug/`.
3. Copy the APK to the phone and install it (allow "install unknown apps").

## First run
Open Settings in the app and enter:
- SinricPro API key: sinric.pro dashboard > Credentials > API Key
- Claude API key (optional): console.anthropic.com
The three device IDs are already filled in from your ESP code.

## Keep the screen on 24/7
The app keeps the screen on only while it is in the foreground. On the phone also:
- Settings > Developer options > "Stay awake" (screen stays on while charging)
- Pin the app (Settings > Security > App pinning) so it can't be left by accident

## Face and voice
- Tap the face (or the mic button) to talk. The face listens (green ripples, mouth follows your voice), thinks (amber, bouncing dots), speaks (violet, moving mouth) and smiles when done.
- Drag the face anywhere in its area; double-tap to send it back to the centre. Eyes follow your finger.
- Settings > "Hands-free" keeps listening after every answer. The system speech recognizer may beep each time; there is no wake word.
- Set "Voice language" (en-US, ru-RU, uz-UZ) if the phone language differs from the one you speak.

## Build without Android Studio (GitHub)
1. Create a free GitHub account and a new empty repository.
2. Upload ALL files of this folder (including the hidden .github folder) to it.
3. Open the Actions tab > "Build APK" > wait for the green check (about 5 minutes).
4. Open the finished run > Artifacts > download SmartHome-apk, unzip it, install app-debug.apk.

## v3 changes
- White theme, fixed (non-draggable) animated face: eyebrows, blush, wink, sleep (zzz), sparkles, antenna, sound bars.
- Full-screen mode (⛶ button): only the face + Listen / Mute / Exit.
- Gemini API key (Settings): the app listens with its own silent recorder (no beeps), sends your voice straight to Gemini, and ignores TV/background talk. Without a Gemini key it uses the Android speech recognizer with the beep muted.
- Voice language is also used for the spoken answer. If the phone has no voice for that language, answers are shown and animated but not spoken.
