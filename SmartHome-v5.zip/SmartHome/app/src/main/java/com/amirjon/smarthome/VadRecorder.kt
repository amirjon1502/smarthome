package com.amirjon.smarthome

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.util.ArrayDeque
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Silent microphone listener (no system beeps). It watches the mic level, starts recording when
 * you speak, stops after about a second of silence, and hands you the recording as a WAV file.
 * After one utterance it stops by itself; the activity starts it again when the answer is done.
 * All callbacks arrive on the main thread.
 */
class VadRecorder(private val cb: Callback) {

    interface Callback {
        fun onLevel(level: Float)
        fun onSpeechStart()
        fun onUtterance(wav: ByteArray)
        fun onTimeout()
        fun onError(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var session = 0
    @Volatile var active = false
        private set

    /** [waitLimitMs] = give up if nobody speaks for that long (0 = listen forever). */
    fun start(waitLimitMs: Long) {
        stop()
        val mine = ++session
        active = true
        Thread { loop(mine, waitLimitMs) }.apply { isDaemon = true; start() }
    }

    fun stop() {
        session++
        active = false
    }

    private fun alive(mine: Int) = mine == session

    private fun loop(mine: Int, waitLimitMs: Long) {
        val rate = 16000
        val chunk = rate / 10                               // 100 ms
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        var rec: AudioRecord? = null
        for (attempt in 0 until 5) {                         // mic may still be busy for a moment
            if (!alive(mine)) return
            val r = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(minBuf, chunk * 4 * 2))
            } catch (e: Exception) { null }
            if (r != null && r.state == AudioRecord.STATE_INITIALIZED) { rec = r; break }
            r?.release()
            try { Thread.sleep(200) } catch (_: InterruptedException) {}
        }
        if (rec == null) {
            if (alive(mine)) { active = false; main.post { cb.onError("Microphone is busy or not allowed") } }
            return
        }

        try {
            rec.startRecording()
            val buf = ShortArray(chunk)
            val pre = ArrayDeque<ShortArray>()               // 400 ms before speech starts
            val speech = ByteArrayOutputStream()
            var noise = 0f
            var calib = 0
            var inSpeech = false
            var loudRun = 0
            var silentMs = 0
            var speechMs = 0
            var waitedMs = 0
            var smooth = 0f

            while (alive(mine)) {
                val n = rec.read(buf, 0, chunk)
                if (n < 0) { main.post { cb.onError("Microphone read error") }; break }
                if (n == 0) continue
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                val rms = sqrt(sum / n).toFloat()

                if (calib < 5) {                              // first half second = background noise
                    noise += rms / 5f
                    calib++
                    continue
                }
                val level = ((rms - noise) / 4000f).coerceIn(0f, 1f)
                smooth = smooth * 0.5f + level * 0.5f
                val shown = smooth
                if (alive(mine)) main.post { cb.onLevel(shown) }

                val loud = rms > max(noise * 2.5f, 500f)
                if (!inSpeech) {
                    if (!loud) noise = noise * 0.95f + rms * 0.05f
                    pre.addLast(buf.copyOf(n))
                    while (pre.size > 4) pre.removeFirst()
                    loudRun = if (loud) loudRun + 1 else 0
                    waitedMs += 100
                    if (loudRun >= 2) {
                        inSpeech = true
                        speechMs = 0
                        silentMs = 0
                        for (c in pre) { writeShorts(speech, c); speechMs += 100 }
                        pre.clear()
                        main.post { if (alive(mine)) cb.onSpeechStart() }
                    } else if (waitLimitMs > 0 && waitedMs >= waitLimitMs) {
                        if (alive(mine)) { active = false; main.post { cb.onTimeout() } }
                        break
                    }
                } else {
                    writeShorts(speech, buf.copyOf(n))
                    speechMs += 100
                    if (loud) silentMs = 0 else silentMs += 100
                    if (silentMs >= 1000 || speechMs >= 15000) {
                        if (speechMs - silentMs >= 400) {
                            val wav = toWav(speech.toByteArray(), rate)
                            if (alive(mine)) {
                                active = false
                                main.post { cb.onLevel(0f); cb.onUtterance(wav) }
                            }
                            break
                        }
                        inSpeech = false                      // too short: a click or cough
                        speech.reset()
                        loudRun = 0
                        silentMs = 0
                    }
                }
            }
        } catch (e: Exception) {
            if (alive(mine)) { active = false; main.post { cb.onError("Microphone error") } }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }
    }

    private fun writeShorts(out: ByteArrayOutputStream, s: ShortArray) {
        for (v in s) {
            out.write(v.toInt() and 0xFF)
            out.write((v.toInt() shr 8) and 0xFF)
        }
    }

    private fun toWav(pcm: ByteArray, rate: Int): ByteArray {
        val total = pcm.size + 36
        val h = ByteArrayOutputStream()
        fun int(v: Int) { for (i in 0..3) h.write((v shr (8 * i)) and 0xFF) }
        fun short(v: Int) { h.write(v and 0xFF); h.write((v shr 8) and 0xFF) }
        h.write("RIFF".toByteArray()); int(total)
        h.write("WAVE".toByteArray())
        h.write("fmt ".toByteArray()); int(16); short(1); short(1)
        int(rate); int(rate * 2); short(2); short(16)
        h.write("data".toByteArray()); int(pcm.size)
        h.write(pcm)
        return h.toByteArray()
    }
}
