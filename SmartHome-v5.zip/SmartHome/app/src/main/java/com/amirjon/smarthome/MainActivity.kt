package com.amirjon.smarthome

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.amirjon.smarthome.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), HomeActions, VoiceInput.Callback {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var sinric: SinricClient
    private lateinit var assistant: Assistant
    private lateinit var voice: VoiceInput            // Android speech recognizer (used without a Gemini key)
    private lateinit var recorder: VadRecorder        // silent recorder (used with a Gemini key)
    private lateinit var sfx: UiSfx

    private var tts: TextToSpeech? = null
    private var ttsInitialized = false
    private var ttsHasVoice = false
    private var pendingSpeech: String? = null
    private var ttsTimeoutRunnable: Runnable? = null

    private val handler = Handler(Looper.getMainLooper())

    private var lightOn: Boolean? = null
    private var ventOn: Boolean? = null
    private var temp: Double? = null
    private var hum: Double? = null
    private var updated: String = ""

    private var busy = false          // assistant is thinking or speaking
    private var lastWasError = false
    private var resumed = false
    private var muted = false
    private var fullscreen = false
    private var beepMuted = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else Toast.makeText(this, "Microphone permission is needed for voice commands", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Keep screen on while app is open
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        hideSystemBars()

        prefs = Prefs(this)
        sfx = UiSfx().apply { enabled = prefs.sfxEnabled }
        sinric = SinricClient(prefs)
        assistant = Assistant(prefs, this)
        voice = VoiceInput(this, this)
        recorder = VadRecorder(recorderCallback)
        initTts()

        b.face.onTap = {
            sfx.playTap()
            if (muted) Toast.makeText(this, "Microphone is muted. Tap Unmute.", Toast.LENGTH_SHORT).show()
            else toggleListening()
        }
        b.btnMic.setOnClickListener { listenButton() }
        b.btnFsListen.setOnClickListener { listenButton() }
        b.btnMute.setOnClickListener { sfx.playTap(); setMuted(!muted) }
        b.btnFsMute.setOnClickListener { sfx.playTap(); setMuted(!muted) }
        b.btnFullscreen.setOnClickListener { sfx.playTap(); applyFullscreen(true) }
        b.btnFsExit.setOnClickListener { sfx.playTap(); applyFullscreen(false) }
        b.btnLight.setOnClickListener { toggle("light") }
        b.btnVent.setOnClickListener { toggle("vent") }
        b.btnSettings.setOnClickListener { sfx.playTap(); showSettings() }
        b.btnSend.setOnClickListener { sfx.playTap(); sendTyped() }
        b.etInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { sfx.playTap(); sendTyped(); true } else false
        }

        if (prefs.sinricKey.isBlank()) showSettings()
        applyFullscreen(prefs.fullscreen)
        render()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ---- live connection runs only while the screen is visible ----
    override fun onStart() {
        super.onStart()
        resumed = true
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { loadInitial() }
                sinric.listen(
                    onStatus = { ok -> runOnUiThread { setConn(ok) } },
                    onEvent = { ev -> runOnUiThread { handleEvent(ev) } }
                )
            }
        }
        if (muted) setFace(FaceView.Mode.MUTED)
        else if (prefs.handsFree) scheduleListen(800)
    }

    override fun onStop() {
        resumed = false
        handler.removeCallbacksAndMessages(null)
        voice.stop()
        recorder.stop()
        setBeepMuted(false)
        tts?.stop()
        busy = false
        b.face.level = 0f
        setFace(FaceView.Mode.IDLE)
        refreshButtons()
        super.onStop()
    }

    private suspend fun loadInitial() {
        sinric.getDevice(prefs.tempId)?.let { applySensor(it) }
        sinric.getDevice(prefs.lightId)?.let { applyPower(prefs.lightId, it) }
        sinric.getDevice(prefs.ventId)?.let { applyPower(prefs.ventId, it) }
        render()
    }

    private fun handleEvent(ev: JSONObject) {
        val id = SinricClient.find(ev, "deviceId") as? String ?: return
        when (id) {
            prefs.tempId -> applySensor(ev)
            prefs.lightId, prefs.ventId -> applyPower(id, ev)
        }
        render()
    }

    private fun applySensor(node: Any) {
        val t = SinricClient.number(node, "temperature")
        val h = SinricClient.number(node, "humidity")
        if (t != null) temp = t
        if (h != null) hum = h
        if (t != null || h != null) updated = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    private fun applyPower(id: String, node: Any) {
        val s = (SinricClient.find(node, "state") as? String)
            ?: (SinricClient.find(node, "powerState") as? String) ?: return
        val on = s.equals("On", true)
        if (id == prefs.lightId) lightOn = on else ventOn = on
    }

    // ---- UI ----
    private fun setConn(ok: Boolean) {
        b.tvConn.text = if (ok) "● ONLINE" else "● OFFLINE"
        b.tvConn.setTextColor(if (ok) Color.parseColor("#12A150") else Color.parseColor("#D92D20"))
    }

    private fun render() {
        b.tvTemp.text = temp?.let { String.format(Locale.US, "%.1f°C", it) } ?: "--"
        b.tvHum.text = hum?.let { String.format(Locale.US, "%.0f%%", it) } ?: "--"
        b.tvUpdated.text = if (updated.isEmpty()) "Waiting for first reading…"
        else "Last updated $updated"
        paint(b.btnLight, "Light", lightOn)
        paint(b.btnVent, "Vent", ventOn)
    }

    private fun paint(btn: MaterialButton, name: String, on: Boolean?) {
        val active = on == true
        btn.text = "$name · " + when (on) { true -> "ON"; false -> "OFF"; null -> "—" }
        val bg = if (active) Color.parseColor("#16A34A") else Color.parseColor("#EEF2F6")
        val fg = if (active) Color.WHITE else Color.parseColor("#1E293B")
        btn.backgroundTintList = ColorStateList.valueOf(bg)
        btn.setTextColor(fg)
        btn.iconTint = ColorStateList.valueOf(fg)
    }

    private fun toggle(device: String) {
        val targetOn = !((if (device == "light") lightOn else ventOn) ?: false)
        sfx.playToggle(targetOn)
        lifecycleScope.launch {
            val msg = setDevice(device, targetOn)
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            if (msg.startsWith("Could not")) {
                sfx.playError()
                b.face.fail()
            } else {
                b.face.celebrate()
            }
        }
    }

    /** Full screen = only the face plus Listen / Mute / Exit. */
    private fun applyFullscreen(fs: Boolean) {
        fullscreen = fs
        prefs.fullscreen = fs
        val normal = if (fs) View.GONE else View.VISIBLE
        b.topBar.visibility = normal
        b.statsRow.visibility = normal
        b.tvUpdated.visibility = normal
        b.tvReply.visibility = normal
        b.switchRow.visibility = normal
        b.inputRow.visibility = normal
        b.fsBar.visibility = if (fs) View.VISIBLE else View.GONE
        refreshButtons()
    }

    private fun isListening() = voice.active || recorder.active

    private fun refreshButtons() {
        val listening = isListening()

        // Main bar compact icon buttons (classic vector icons, zero emojis)
        b.btnMic.icon = ContextCompat.getDrawable(this, if (listening) R.drawable.ic_stop else R.drawable.ic_mic)
        val micBg = if (listening) Color.parseColor("#DC2626") else Color.parseColor("#2563EB")
        b.btnMic.backgroundTintList = ColorStateList.valueOf(micBg)

        b.btnMute.icon = ContextCompat.getDrawable(this, if (muted) R.drawable.ic_mic else R.drawable.ic_mic_off)
        val muteBg = if (muted) Color.parseColor("#D97706") else Color.parseColor("#475569")
        b.btnMute.backgroundTintList = ColorStateList.valueOf(muteBg)

        // Fullscreen buttons
        b.btnFsListen.icon = ContextCompat.getDrawable(this, if (listening) R.drawable.ic_stop else R.drawable.ic_mic)
        b.btnFsListen.text = if (listening) "Stop" else "Listen"
        b.btnFsListen.backgroundTintList = ColorStateList.valueOf(micBg)

        b.btnFsMute.icon = ContextCompat.getDrawable(this, if (muted) R.drawable.ic_mic else R.drawable.ic_mic_off)
        b.btnFsMute.text = if (muted) "Unmute" else "Mute"
        b.btnFsMute.backgroundTintList = ColorStateList.valueOf(muteBg)
    }

    /** Changes the face unless the mic is muted. */
    private fun setFace(m: FaceView.Mode) {
        b.face.mode = if (muted) FaceView.Mode.MUTED else m
    }

    // ---- Text-To-Speech (Fixed: robust locale fallback + guaranteed audio routing & turn completion) ----
    private fun initTts() {
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val wanted = if (prefs.voiceLang.isBlank()) Locale.getDefault()
                else Locale.forLanguageTag(prefs.voiceLang)

                var r = engine.setLanguage(wanted)
                // Critical Fix: if phone lacks a specific pack (e.g. uz-UZ), fall back to English or default
                // instead of muting the AI completely!
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = engine.setLanguage(Locale.US)
                }
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = engine.setLanguage(Locale.getDefault())
                }

                ttsInitialized = true
                ttsHasVoice = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED

                engine.setSpeechRate(1.02f)
                engine.setPitch(1.0f)
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        runOnUiThread {
                            setFace(FaceView.Mode.SPEAKING)
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            clearTtsWatchdog()
                            finishTurn()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            clearTtsWatchdog()
                            finishTurn()
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        runOnUiThread {
                            clearTtsWatchdog()
                            finishTurn()
                        }
                    }
                })

                // Speak any response that arrived while TTS engine was still booting up
                pendingSpeech?.let { queued ->
                    pendingSpeech = null
                    runOnUiThread { speakOut(queued) }
                }
            }
        }
    }

    private fun clearTtsWatchdog() {
        ttsTimeoutRunnable?.let { handler.removeCallbacks(it) }
        ttsTimeoutRunnable = null
    }

    private fun ensureAudioAudible() {
        setBeepMuted(false)
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .build()
            try { am.requestAudioFocus(req) } catch (_: Exception) {}
        }
        // Ensure media stream isn't accidentally stuck at 0 after speech recognizer muting
        try {
            if (am.isStreamMute(AudioManager.STREAM_MUSIC)) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (cur == 0 && max > 0) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.6f).toInt().coerceAtLeast(1), 0)
            }
        } catch (_: Exception) {}
    }

    private fun speakOut(rawText: String) {
        val cleanText = rawText
            .replace("*", "")
            .replace("#", "")
            .replace("`", "")
            .replace(Regex("\s+"), " ")
            .trim()

        if (cleanText.isEmpty()) {
            finishTurn()
            return
        }

        if (!ttsInitialized) {
            pendingSpeech = cleanText
            setFace(FaceView.Mode.SPEAKING)
            return
        }

        val engine = tts
        if (engine == null || !ttsHasVoice) {
            finishTurn()
            return
        }

        ensureAudioAudible()
        setFace(FaceView.Mode.SPEAKING)

        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }
        val uid = "reply_${System.currentTimeMillis()}"
        val res = engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, uid)

        if (res == TextToSpeech.ERROR) {
            finishTurn()
            return
        }

        // Safety watchdog in case a buggy OEM TTS engine never fires onDone()
        clearTtsWatchdog()
        val estMs = (cleanText.length * 85L).coerceIn(3000L, 18000L)
        val watchdog = Runnable {
            if (busy && b.face.mode == FaceView.Mode.SPEAKING) {
                finishTurn()
            }
        }
        ttsTimeoutRunnable = watchdog
        handler.postDelayed(watchdog, estMs)
    }

    // ---- mic: mute / listen ----
    private fun setMuted(m: Boolean) {
        muted = m
        if (m) {
            stopListening()
            clearTtsWatchdog()
            tts?.stop()
            busy = false
            handler.removeCallbacksAndMessages(null)
            b.face.mode = FaceView.Mode.MUTED
            b.tvReply.text = "Microphone muted."
        } else {
            b.face.mode = FaceView.Mode.IDLE
            b.tvReply.text = "Microphone active. Tap the face to talk."
            if (prefs.handsFree) scheduleListen(300)
        }
        refreshButtons()
    }

    private fun listenButton() {
        if (muted) { sfx.playTap(); setMuted(false); return }
        toggleListening()
    }

    private fun toggleListening() {
        when {
            busy -> {                       // tapping while it talks = stop talking
                sfx.playListenStop()
                clearTtsWatchdog()
                tts?.stop()
                busy = false
                setFace(FaceView.Mode.IDLE)
            }
            isListening() -> {
                sfx.playListenStop()
                stopListening()
                b.tvReply.text = "Stopped listening."
            }
            else -> {
                sfx.playListenStart()
                startListening()
            }
        }
        refreshButtons()
    }

    private fun stopListening() {
        voice.stop()
        recorder.stop()
        setBeepMuted(false)
        b.face.level = 0f
        if (!muted && b.face.mode == FaceView.Mode.LISTENING) b.face.mode = FaceView.Mode.IDLE
        refreshButtons()
    }

    private fun startListening() {
        if (busy || !resumed || muted) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        // Make sure TTS isn't holding audio while recording starts
        tts?.stop()

        if (prefs.geminiKey.isNotBlank()) {
            b.face.mode = FaceView.Mode.LISTENING
            b.tvReply.text = "Listening…"
            recorder.start(if (prefs.handsFree) 0L else 8000L)
        } else {
            if (!voice.available()) {
                Toast.makeText(this, "Speech recognition is not available. Install/enable the Google app.", Toast.LENGTH_LONG).show()
                return
            }
            setBeepMuted(true)
            b.face.mode = FaceView.Mode.LISTENING
            b.tvReply.text = "Listening…"
            voice.start(prefs.voiceLang)
        }
        refreshButtons()
    }

    private fun scheduleListen(delayMs: Long) {
        handler.postDelayed({
            if (prefs.handsFree && resumed && !busy && !muted && !isListening()) startListening()
        }, delayMs)
    }

    /** Mutes only notification/system beeps while system recognizer listens (never mutes MEDIA/TTS). */
    private fun setBeepMuted(m: Boolean) {
        if (m == beepMuted) return
        beepMuted = m
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val dir = if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (st in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try { am.adjustStreamVolume(st, dir, 0) } catch (_: Exception) {}
        }
    }

    // ---- Gemini path: silent recorder ----
    private val recorderCallback = object : VadRecorder.Callback {
        override fun onLevel(level: Float) { b.face.level = level }
        override fun onSpeechStart() { b.tvReply.text = "Hearing you…" }
        override fun onUtterance(wav: ByteArray) { runAssistantAudio(wav) }
        override fun onTimeout() {
            setFace(FaceView.Mode.IDLE)
            b.tvReply.text = "I didn't hear anything. Tap the face and speak."
            refreshButtons()
        }
        override fun onError(message: String) {
            sfx.playError()
            b.face.level = 0f
            b.face.fail()
            b.tvReply.text = message
            refreshButtons()
            if (prefs.handsFree) scheduleListen(4000)
        }
    }

    // ---- system recognizer path (VoiceInput.Callback) ----
    override fun onLevel(level: Float) { b.face.level = level }

    override fun onPartial(text: String) { b.tvReply.text = "“$text”" }

    override fun onFinal(text: String) {
        setBeepMuted(false)
        runAssistant(text)
    }

    override fun onFail(code: Int) {
        setBeepMuted(false)
        b.face.level = 0f
        refreshButtons()
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                setFace(FaceView.Mode.IDLE)
                if (prefs.handsFree) scheduleListen(400)
                else b.tvReply.text = "I didn't catch that. Tap me and try again."
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                setFace(FaceView.Mode.IDLE)
                scheduleListen(900)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else -> {
                sfx.playError()
                b.face.fail()
                b.tvReply.text = "Voice error ($code). Check internet and the Google app."
                if (prefs.handsFree) scheduleListen(4000)
            }
        }
    }

    // ---- assistant ----
    private fun sendTyped() {
        val t = b.etInput.text.toString().trim()
        if (t.isEmpty()) return
        b.etInput.setText("")
        stopListening()
        busy = false
        runAssistant(t)
    }

    private fun runAssistant(text: String) {
        busy = true
        b.face.level = 0f
        setFace(FaceView.Mode.THINKING)
        b.tvReply.text = "You: $text"
        refreshButtons()
        lifecycleScope.launch {
            val reply = assistant.handle(text)
            deliver("You: $text

$reply", reply)
        }
    }

    private fun runAssistantAudio(wav: ByteArray) {
        busy = true
        b.face.level = 0f
        setFace(FaceView.Mode.THINKING)
        b.tvReply.text = "Thinking…"
        refreshButtons()
        lifecycleScope.launch {
            val reply = assistant.handleAudio(wav)
            if (reply == Assistant.IGNORE) {               // background noise: go back to listening quietly
                busy = false
                setFace(FaceView.Mode.IDLE)
                b.tvReply.text = "Listening…"
                refreshButtons()
                if (prefs.handsFree) scheduleListen(150)
                return@launch
            }
            deliver(reply, reply)
        }
    }

    private fun deliver(shown: String, spoken: String) {
        if (muted) { busy = false; return }
        lastWasError = spoken.startsWith("Could not") || spoken.startsWith("AI unavailable") ||
            spoken.startsWith("No answer") || spoken.startsWith("Add a Gemini")
        b.tvReply.text = shown
        if (!lastWasError) {
            sfx.playSuccess()
            speakOut(spoken)
        } else {
            sfx.playError()
            finishTurn()
        }
    }

    private fun finishTurn() {
        busy = false
        refreshButtons()
        if (muted) return
        if (lastWasError) b.face.fail() else b.face.celebrate()
        if (prefs.handsFree) scheduleListen(1200)
    }

    // ---- HomeActions (used by the assistant and the buttons) ----
    override suspend fun setDevice(device: String, on: Boolean): String {
        val id = if (device == "light") prefs.lightId else prefs.ventId
        val label = if (device == "light") "Light" else "Vent"
        val ok = sinric.setPower(id, on)
        return if (ok) {
            if (device == "light") lightOn = on else ventOn = on
            render()
            "$label turned ${if (on) "on" else "off"}."
        } else "Could not reach SinricPro. Check the API key and internet."
    }

    override fun status(): String {
        val t = temp?.let { String.format(Locale.US, "%.1f°C", it) } ?: "unknown"
        val h = hum?.let { String.format(Locale.US, "%.0f%%", it) } ?: "unknown"
        fun s(v: Boolean?) = when (v) { true -> "on"; false -> "off"; null -> "unknown" }
        return "Temperature $t, humidity $h, light ${s(lightOn)}, vent ${s(ventOn)}."
    }

    // ---- settings ----
    private fun showSettings() {
        fun field(label: String, value: String, secret: Boolean = false) = EditText(this).apply {
            hint = label
            setText(value)
            setTextColor(Color.parseColor("#1B2430"))
            if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val key = field("SinricPro API key (Dashboard → Credentials)", prefs.sinricKey, true)
        val gemini = field("Gemini API key (voice + AI, no beeps)", prefs.geminiKey, true)
        val geminiModel = field("Gemini model (default ${Prefs.DEFAULT_GEMINI_MODEL})", prefs.geminiModel)
        val claude = field("Claude API key (optional, text AI)", prefs.claudeKey, true)
        val light = field("Light device ID", prefs.lightId)
        val vent = field("Vent device ID", prefs.ventId)
        val tempF = field("Temperature sensor device ID", prefs.tempId)
        val lang = field("Voice language (en-US, ru-RU, uz-UZ… blank = phone)", prefs.voiceLang)
        val hands = CheckBox(this).apply {
            text = "Hands-free: keep listening after every answer"
            isChecked = prefs.handsFree
        }
        val sfxCheck = CheckBox(this).apply {
            text = "GUI sound effects (classic clicks & chimes)"
            isChecked = prefs.sfxEnabled
        }
        val info = TextView(this).apply {
            text = "AI order: Gemini key → Claude key → simple commands. With a Gemini key the mic is silent (no beeps)."
            textSize = 12f
            setTextColor(Color.parseColor("#5B6778"))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            listOf(key, gemini, geminiModel, claude, light, vent, tempF, lang, hands, sfxCheck, info).forEach { addView(it) }
        }
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                prefs.sinricKey = key.text.toString()
                prefs.geminiKey = gemini.text.toString()
                prefs.geminiModel = geminiModel.text.toString().ifBlank { Prefs.DEFAULT_GEMINI_MODEL }
                prefs.claudeKey = claude.text.toString()
                prefs.lightId = light.text.toString()
                prefs.ventId = vent.text.toString()
                prefs.tempId = tempF.text.toString()
                prefs.voiceLang = lang.text.toString()
                prefs.handsFree = hands.isChecked
                prefs.sfxEnabled = sfxCheck.isChecked
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        clearTtsWatchdog()
        voice.stop()
        recorder.stop()
        setBeepMuted(false)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
