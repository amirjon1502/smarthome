package com.amirjon.smarthome

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** What the assistant is allowed to do in the house. */
interface HomeActions {
    suspend fun setDevice(device: String, on: Boolean): String   // device = "light" | "vent"
    fun status(): String
}

/**
 * AI assistant. Picks the brain automatically:
 *  1. Gemini key set  -> Gemini (understands your VOICE directly, any language, can call home tools)
 *  2. Claude key set  -> Claude (text commands)
 *  3. no key          -> simple keyword commands (English / Russian / Uzbek)
 */
class Assistant(private val prefs: Prefs, private val home: HomeActions) {

    companion object {
        /** Gemini answers with this when the audio was not meant for the assistant. */
        const val IGNORE = "IGNORE"
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val claudeModel = "claude-haiku-5-5"

    private val system = """
        You are the voice assistant of a smart home. You control a light and a ventilation fan
        (vent) and can read temperature and humidity. Use the tools to act; never claim you did
        something without calling the tool. Reply in the language the user speaks (Uzbek, Russian,
        English...), in one or two short sentences, plain text without markdown or emojis,
        because the answer is shown on a screen and read aloud.
    """.trimIndent()

    private val audioRule = """
        The user message is an audio recording from a microphone that is always on. If it is only
        background noise, a TV, music, or people talking to each other and it is not a request or a
        command for the home assistant, reply with exactly: $IGNORE
        Otherwise answer the request.
    """.trimIndent()

    val usesGemini get() = prefs.geminiKey.isNotBlank()

    suspend fun handle(text: String): String {
        return try {
            when {
                prefs.geminiKey.isNotBlank() ->
                    askGemini(JSONArray().put(JSONObject().put("text", text)), audio = false)
                prefs.claudeKey.isNotBlank() -> askClaude(text)
                else -> offline(text)
            }
        } catch (e: Exception) {
            "AI unavailable (${e.message?.take(60)}). " + offline(text)
        }
    }

    /** Voice straight to Gemini (no speech-to-text step). Returns [IGNORE] for background noise. */
    suspend fun handleAudio(wav: ByteArray): String {
        if (prefs.geminiKey.isBlank()) return "Add a Gemini API key in Settings for voice."
        return try {
            val parts = JSONArray()
                .put(JSONObject().put("text", "Voice message from the user:"))
                .put(JSONObject().put("inlineData", JSONObject()
                    .put("mimeType", "audio/wav")
                    .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            askGemini(parts, audio = true)
        } catch (e: Exception) {
            "AI unavailable (${e.message?.take(60)})."
        }
    }

    // ---------- shared tool runner ----------
    private suspend fun runTool(name: String, input: JSONObject): String = when (name) {
        "control_device" -> home.setDevice(input.optString("device"), input.optString("state") == "on")
        "get_status" -> home.status()
        else -> "Unknown tool"
    }

    // ---------- Gemini ----------
    private fun geminiTools() = JSONArray().put(
        JSONObject().put("functionDeclarations", JSONArray()
            .put(JSONObject()
                .put("name", "control_device")
                .put("description", "Turn the light or the ventilation fan on or off.")
                .put("parameters", JSONObject()
                    .put("type", "OBJECT")
                    .put("properties", JSONObject()
                        .put("device", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("light", "vent"))))
                        .put("state", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("on", "off")))))
                    .put("required", JSONArray(listOf("device", "state")))))
            .put(JSONObject()
                .put("name", "get_status")
                .put("description", "Get current temperature, humidity, and light/vent state.")))
    )

    private suspend fun askGemini(userParts: JSONArray, audio: Boolean): String {
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", userParts))
        repeat(4) {
            val resp = postGemini(contents, audio)
            val content = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return "No answer from Gemini."
            val parts = content.optJSONArray("parts") ?: return "No answer from Gemini."

            val calls = ArrayList<JSONObject>()
            val text = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("functionCall")) calls.add(p.getJSONObject("functionCall"))
                else if (p.has("text") && !p.optBoolean("thought", false)) text.append(p.getString("text"))
            }
            if (calls.isEmpty()) {
                val t = text.toString()
                    .replace("*", "")
                    .replace("#", "")
                    .replace("`", "")
                    .trim()
                return if (t.startsWith(IGNORE)) IGNORE else t.ifBlank { "Done." }
            }

            contents.put(JSONObject().put("role", "model").put("parts", parts))
            val results = JSONArray()
            for (fc in calls) {
                val out = runTool(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
                results.put(JSONObject().put("functionResponse", JSONObject()
                    .put("name", fc.getString("name"))
                    .put("response", JSONObject().put("result", out))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", results))
        }
        return "Done."
    }

    private suspend fun postGemini(contents: JSONArray, audio: Boolean): JSONObject = withContext(Dispatchers.IO) {
        val sys = if (audio) system + "
" + audioRule else system
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("tools", geminiTools())
            .toString()

        val configuredModel = prefs.geminiModel.ifBlank { Prefs.DEFAULT_GEMINI_MODEL }
        val candidates = linkedSetOf(configuredModel, "gemini-2.5-flash-lite", "gemini-2.5-flash")

        var lastError = "Gemini request failed"
        for (model in candidates) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", prefs.geminiKey)
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                val s = r.body?.string() ?: ""
                if (r.isSuccessful) {
                    return@withContext JSONObject(s)
                }
                val msg = try { JSONObject(s).getJSONObject("error").optString("message") } catch (_: Exception) { "" }
                lastError = "Gemini HTTP ${r.code} ${msg.take(60)}"
                // If model name isn't found (404), try fallback model; otherwise fail immediately
                if (r.code != 404) {
                    throw RuntimeException(lastError)
                }
            }
        }
        throw RuntimeException(lastError)
    }

    // ---------- Claude with tool use ----------
    private val claudeTools = JSONArray().put(
        JSONObject()
            .put("name", "control_device")
            .put("description", "Turn the light or the ventilation fan on or off.")
            .put("input_schema", JSONObject()
                .put("type", "object")
                .put("properties", JSONObject()
                    .put("device", JSONObject().put("type", "string").put("enum", JSONArray(listOf("light", "vent"))))
                    .put("state", JSONObject().put("type", "string").put("enum", JSONArray(listOf("on", "off")))))
                .put("required", JSONArray(listOf("device", "state"))))
    ).put(
        JSONObject()
            .put("name", "get_status")
            .put("description", "Get current temperature, humidity, and light/vent state.")
            .put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
    )

    private suspend fun askClaude(text: String): String {
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", text))
        repeat(4) {
            val resp = postClaude(messages)
            val content = resp.getJSONArray("content")
            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().replace("*", "").ifBlank { "Done." }
            }
            messages.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") != "tool_use") continue
                val out = runTool(b.getString("name"), b.getJSONObject("input"))
                results.put(JSONObject()
                    .put("type", "tool_result")
                    .put("tool_use_id", b.getString("id"))
                    .put("content", out))
            }
            messages.put(JSONObject().put("role", "user").put("content", results))
        }
        return "Done."
    }

    private suspend fun postClaude(messages: JSONArray): JSONObject = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", claudeModel)
            .put("max_tokens", 512)
            .put("system", system)
            .put("tools", claudeTools)
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", prefs.claudeKey)
            .header("anthropic-version", "2023-06-01")
            .post(body)
            .build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}")
            JSONObject(s)
        }
    }

    // ---------- Offline keyword fallback (English / Russian / Uzbek) ----------
    private suspend fun offline(text: String): String {
        val t = text.lowercase()
        val light = listOf("light", "lamp", "свет", "лампа", "chiroq", "yorug").any { t.contains(it) }
        val vent = listOf("vent", "fan", "вентил", "вытяж", "ventilyator", "shamollat").any { t.contains(it) }
        val off = listOf("off", "выкл", "погас", "o'chir", "ochir", "o‘chir").any { t.contains(it) }
        val on = listOf("on", "вкл", "зажг", "yoq", "yoqing").any { t.contains(it) }

        if (light || vent) {
            val state = when {
                off -> false
                on -> true
                else -> return "Say on or off."
            }
            val parts = mutableListOf<String>()
            if (light) parts += home.setDevice("light", state)
            if (vent) parts += home.setDevice("vent", state)
            return parts.joinToString(" ")
        }
        if (listOf("temp", "hum", "темпер", "влаж", "harorat", "namlik", "status").any { t.contains(it) })
            return home.status()
        return "I did not understand. Add a Gemini or Claude API key in Settings for full AI."
    }
}
