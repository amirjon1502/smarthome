package com.amirjon.smarthome

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Procedural classic GUI sound effects engine.
 * Synthesizes clean, crisp, subtle tactile sounds (no external audio assets required).
 */
class UiSfx {

    var enabled: Boolean = true
    private val scope = CoroutineScope(Dispatchers.Default)

    fun playTap() = playTone(freqs = doubleArrayOf(920.0), durationsMs = intArrayOf(28), volume = 0.22f)

    fun playToggle(on: Boolean) {
        if (on) {
            playTone(freqs = doubleArrayOf(587.33, 880.0), durationsMs = intArrayOf(45, 70), volume = 0.25f)
        } else {
            playTone(freqs = doubleArrayOf(659.25, 440.0), durationsMs = intArrayOf(45, 70), volume = 0.22f)
        }
    }

    fun playListenStart() = playTone(
        freqs = doubleArrayOf(523.25, 659.25, 783.99),
        durationsMs = intArrayOf(40, 40, 65),
        volume = 0.24f
    )

    fun playListenStop() = playTone(
        freqs = doubleArrayOf(659.25, 493.88),
        durationsMs = intArrayOf(40, 60),
        volume = 0.20f
    )

    fun playSuccess() = playTone(
        freqs = doubleArrayOf(659.25, 987.77),
        durationsMs = intArrayOf(55, 95),
        volume = 0.24f
    )

    fun playError() = playTone(
        freqs = doubleArrayOf(311.13, 233.08),
        durationsMs = intArrayOf(80, 120),
        volume = 0.26f
    )

    private fun playTone(freqs: DoubleArray, durationsMs: IntArray, volume: Float) {
        if (!enabled) return
        scope.launch {
            try {
                val sampleRate = 22050
                var totalSamples = 0
                for (d in durationsMs) totalSamples += (sampleRate * d) / 1000
                if (totalSamples <= 0) return@launch

                val pcm = ShortArray(totalSamples)
                var offset = 0
                for (idx in freqs.indices) {
                    val freq = freqs[idx]
                    val count = (sampleRate * durationsMs[idx]) / 1000
                    for (i in 0 until count) {
                        val t = i.toDouble() / sampleRate
                        val progress = i.toDouble() / count
                        // Smooth attack + exponential decay envelope for clean acoustic feel
                        val attack = (i / (sampleRate * 0.004)).coerceAtMost(1.0)
                        val decay = exp(-4.5 * progress)
                        val env = attack * decay
                        // Fundamental + soft harmonic overtone
                        val wave = sin(2.0 * PI * freq * t) * 0.85 + sin(4.0 * PI * freq * t) * 0.15
                        val sample = (wave * env * volume * Short.MAX_VALUE).toInt()
                            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        pcm[offset + i] = sample.toShort()
                    }
                    offset += count
                }

                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val format = AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()

                val track = AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                val totalMs = durationsMs.sum().toLong() + 40L
                Thread.sleep(totalMs)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }
}
