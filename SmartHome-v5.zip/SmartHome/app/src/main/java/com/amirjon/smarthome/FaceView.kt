package com.amirjon.smarthome

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animated robot face for a LIGHT background, drawn on a Canvas (no images). The face stays fixed.
 *
 * Alive details: blinking, wandering eyes that follow your finger, eyebrows, blush, a wink every now and
 * then, a glowing antenna, sound bars, sparkles when happy, and it falls asleep (zzz) when left alone.
 *
 * Modes: IDLE, LISTENING, THINKING, SPEAKING, HAPPY, ERROR, SLEEP, MUTED.
 */
class FaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, ERROR, SLEEP, MUTED }

    var mode: Mode = Mode.IDLE
        set(v) {
            if (field != v) { field = v; modeTime = 0f }
        }

    /** Microphone loudness 0..1, set while listening. */
    var level = 0f

    var onTap: (() -> Unit)? = null

    fun celebrate() { if (mode != Mode.MUTED) mode = Mode.HAPPY }
    fun fail() { if (mode != Mode.MUTED) mode = Mode.ERROR }

    // ---------- animation state ----------
    private var time = 0f
    private var modeTime = 0f
    private var lastNanos = 0L
    private var prevMode = Mode.IDLE

    private val rgb = floatArrayOf(43f, 123f, 255f)
    private var eyeScale = 1f
    private var eyeH = 1f
    private var happy = 0f
    private var curve = 0.35f
    private var open = 0f
    private var listenAmt = 0f
    private var thinkAmt = 0f
    private var barsAmt = 0f
    private var sleepAmt = 0f
    private var smoothLevel = 0f
    private var browLift = 0f
    private var browTilt = 0f
    private var browAsym = 0f

    private var gx = 0f
    private var gy = 0f
    private var tgx = 0f
    private var tgy = 0f
    private var nextWander = 1f

    private var nextBlink = 2f
    private var blinkP = -1f
    private var blink = 1f

    private var nextWink = 14f
    private var winkP = -1f
    private var winkAmt = 0f

    // ---------- touch ----------
    private var touching = false
    private var touchGx = 0f
    private var touchGy = 0f
    private var downX = 0f
    private var downY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    // ---------- sparkles ----------
    private class Spark(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val size: Float, val color: Int)
    private val sparks = ArrayList<Spark>()
    private val sparkColors = intArrayOf(
        Color.rgb(43, 123, 255), Color.rgb(247, 144, 9), Color.rgb(255, 105, 150),
        Color.rgb(18, 183, 106), Color.rgb(122, 90, 248)
    )

    // ---------- drawing tools ----------
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private val cIdle = floatArrayOf(43f, 123f, 255f)
    private val cListen = floatArrayOf(18f, 183f, 106f)
    private val cThink = floatArrayOf(247f, 144f, 9f)
    private val cSpeak = floatArrayOf(122f, 90f, 248f)
    private val cHappy = floatArrayOf(18f, 183f, 106f)
    private val cError = floatArrayOf(240f, 68f, 56f)
    private val cSleep = floatArrayOf(148f, 163f, 184f)

    init {
        contentDescription = "AI assistant face"
        isClickable = true
        p.typeface = Typeface.DEFAULT_BOLD
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = min(0.05f, (now - lastNanos) / 1e9f)
            lastNanos = now
            step(dt)
            invalidate()
            postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNanos = System.nanoTime()
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    private fun approach(cur: Float, target: Float, k: Float, dt: Float) =
        cur + (target - cur) * (1f - exp(-k * dt))

    private fun rand(a: Float, b: Float) = Random.nextFloat() * (b - a) + a

    private fun spawnSparks() {
        sparks.clear()
        repeat(18) {
            val a = rand(0f, (2 * PI).toFloat())
            val sp = rand(0.15f, 0.42f)
            sparks.add(
                Spark(rand(-0.25f, 0.25f), rand(-0.2f, 0.1f), cos(a) * sp, sin(a) * sp - 0.1f,
                    1f, rand(0.015f, 0.03f), sparkColors[Random.nextInt(sparkColors.size)])
            )
        }
    }

    // ---------- per-frame logic ----------
    private fun step(dt: Float) {
        time += dt
        modeTime += dt
        if ((mode == Mode.HAPPY && modeTime > 1.6f) || (mode == Mode.ERROR && modeTime > 2f)) mode = Mode.IDLE
        if (mode == Mode.IDLE && modeTime > 60f && !touching) mode = Mode.SLEEP
        if (mode == Mode.HAPPY && prevMode != Mode.HAPPY) spawnSparks()
        prevMode = mode
        smoothLevel = approach(smoothLevel, level, 14f, dt)

        var tEyeScale = 1f
        var tEyeH = 1f
        var tHappy = 0f
        var tCurve = 0.35f
        var tOpen = 0f
        var tc = cIdle
        var tl = 0f
        var tt = 0f
        var tb = 0f
        var tSleep = 0f
        var tLift = 0f
        var tTilt = 0f
        var tAsym = 0f
        var mouthSpeed = 12f

        // wink (idle only)
        if (mode != Mode.IDLE) winkP = -1f
        else if (winkP < 0f && time > nextWink) winkP = 0f
        if (winkP >= 0f) {
            winkP += dt / 0.55f
            if (winkP >= 1f) { winkP = -1f; nextWink = time + rand(18f, 35f) }
        }
        winkAmt = if (winkP < 0f) 0f else sin(PI.toFloat() * winkP)

        when (mode) {
            Mode.IDLE -> {
                tCurve = 0.35f + 0.5f * winkAmt
                if (!touching && time > nextWander) {
                    tgx = rand(-0.7f, 0.7f); tgy = rand(-0.4f, 0.4f)
                    nextWander = time + rand(1.5f, 3.5f)
                }
            }
            Mode.LISTENING -> {
                tEyeScale = 1.1f + 0.12f * smoothLevel
                tCurve = 0f
                tOpen = 0.1f + 0.7f * smoothLevel
                tc = cListen; tl = 1f; tb = 1f
                tgx = 0f; tgy = -0.15f
                tLift = 0.8f; tTilt = -0.3f
                mouthSpeed = 18f
            }
            Mode.THINKING -> {
                tEyeH = 0.55f
                tCurve = 0f
                tc = cThink; tt = 1f
                tgx = sin(time * 2.4f) * 0.7f; tgy = -0.35f
                tLift = 0.3f; tAsym = 0.9f
            }
            Mode.SPEAKING -> {
                tOpen = (0.2f + 0.8f * abs(sin(time * 9f) * sin(time * 5.3f + 1f))) * 0.85f
                tCurve = 0.25f
                tc = cSpeak; tb = 1f
                tgx = sin(time * 0.9f) * 0.2f; tgy = 0f
                tLift = 0.1f + tOpen * 0.5f
                mouthSpeed = 22f
            }
            Mode.HAPPY -> {
                tHappy = 1f; tCurve = 1f; tOpen = 0.12f; tc = cHappy
                tgx = 0f; tgy = 0f
                tLift = 1f; tTilt = -0.2f
            }
            Mode.ERROR -> {
                tEyeH = 0.7f; tCurve = -0.7f; tc = cError
                tgx = sin(time * 30f) * 0.15f * max(0f, 1f - modeTime * 2f); tgy = 0.1f
                tTilt = -1f; tLift = 0.2f
            }
            Mode.SLEEP -> {
                tEyeH = 0.1f; tCurve = 0.2f; tc = cSleep; tSleep = 1f
                tgx = 0f; tgy = 0.2f; tLift = -0.5f
            }
            Mode.MUTED -> {
                tEyeH = 0.1f; tCurve = 0f; tc = cSleep
                tgx = 0f; tgy = 0.2f; tLift = -0.5f
            }
        }

        if (touching && (mode == Mode.IDLE || mode == Mode.LISTENING || mode == Mode.SLEEP)) {
            tgx = touchGx; tgy = touchGy
        }

        eyeScale = approach(eyeScale, tEyeScale, 10f, dt)
        eyeH = approach(eyeH, tEyeH, 9f, dt)
        happy = approach(happy, tHappy, 12f, dt)
        curve = approach(curve, tCurve, 9f, dt)
        open = approach(open, tOpen, mouthSpeed, dt)
        listenAmt = approach(listenAmt, tl, 6f, dt)
        thinkAmt = approach(thinkAmt, tt, 8f, dt)
        barsAmt = approach(barsAmt, tb, 7f, dt)
        sleepAmt = approach(sleepAmt, tSleep, 4f, dt)
        browLift = approach(browLift, tLift, 9f, dt)
        browTilt = approach(browTilt, tTilt, 9f, dt)
        browAsym = approach(browAsym, tAsym, 9f, dt)
        gx = approach(gx, tgx, 8f, dt)
        gy = approach(gy, tgy, 8f, dt)
        for (i in 0..2) rgb[i] = approach(rgb[i], tc[i], 6f, dt)

        // blinking
        if (blinkP < 0f) {
            if (time > nextBlink && happy < 0.5f) blinkP = 0f
        } else {
            blinkP += dt / 0.18f
            if (blinkP >= 1f) { blinkP = -1f; nextBlink = time + rand(2.5f, 5.5f) }
        }
        blink = if (blinkP < 0f) 1f else 1f - sin(PI.toFloat() * blinkP)

        // sparkles
        val it = sparks.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.x += s.vx * dt; s.y += s.vy * dt
            s.vy += 0.25f * dt
            s.life -= dt / 1.1f
            if (s.life <= 0f) it.remove()
        }
    }

    // ---------- drawing ----------
    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val col = Color.rgb(rgb[0].toInt().coerceIn(0, 255), rgb[1].toInt().coerceIn(0, 255), rgb[2].toInt().coerceIn(0, 255))

        canvas.save()
        val sleepBreath = if (sleepAmt > 0.5f) 0.02f * sin(time * 1.1f) else 0f
        val breathe = 1f + 0.015f * sin(time * 1.7f) + sleepBreath + 0.03f * smoothLevel * listenAmt
        canvas.translate(width / 2f, height / 2f + sin(time * 1.2f) * s * 0.01f)
        canvas.scale(breathe, breathe)

        val pw = s * 0.80f
        val ph = s * 0.62f

        // listening ripples
        if (listenAmt > 0.01f) {
            for (k in 0..1) {
                val phase = (time * 0.7f + k * 0.5f) % 1f
                val grow = phase * s * 0.07f
                rect.set(-pw / 2 - grow, -ph / 2 - grow, pw / 2 + grow, ph / 2 + grow)
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.008f
                p.color = col
                p.alpha = ((1f - phase) * 150f * listenAmt).toInt()
                canvas.drawRoundRect(rect, s * 0.14f + grow, s * 0.14f + grow, p)
            }
        }

        drawAntenna(canvas, s, ph, col)

        // soft shadow under the panel
        p.style = Paint.Style.FILL
        for (i in 4 downTo 1) {
            val g = i * s * 0.008f
            rect.set(-pw / 2 - g * 0.5f, -ph / 2 + g, pw / 2 + g * 0.5f, ph / 2 + g * 1.6f)
            p.color = Color.rgb(27, 36, 48)
            p.alpha = 9
            canvas.drawRoundRect(rect, s * 0.14f + g, s * 0.14f + g, p)
        }

        // panel
        rect.set(-pw / 2, -ph / 2, pw / 2, ph / 2)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(243, 246, 251)
        p.alpha = 255
        canvas.drawRoundRect(rect, s * 0.14f, s * 0.14f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.014f
        p.color = col
        p.alpha = 150
        canvas.drawRoundRect(rect, s * 0.14f, s * 0.14f, p)

        // blush
        if (happy > 0.02f) {
            p.style = Paint.Style.FILL
            p.color = Color.rgb(255, 143, 171)
            p.alpha = (120 * happy).toInt()
            canvas.drawCircle(-s * 0.27f, s * 0.07f, s * 0.045f, p)
            canvas.drawCircle(s * 0.27f, s * 0.07f, s * 0.045f, p)
        }

        // eyes + brows
        val baseH = s * 0.22f * eyeScale * eyeH
        val eyeW = s * 0.14f * eyeScale
        val ey = -s * 0.04f + gy * s * 0.035f
        for (side in intArrayOf(-1, 1)) {
            val ex = side * s * 0.17f + gx * s * 0.045f
            val lid = if (side == 1) 1f - 0.92f * winkAmt else 1f
            val h = baseH * max(blink, 0.08f) * lid
            drawEye(canvas, ex, ey, eyeW, h, s, col)
            drawBrow(canvas, side, ex, ey - baseH / 2 - s * 0.05f, s, col)
        }

        // mouth
        drawMouth(canvas, gx * s * 0.015f, s * 0.17f + gy * s * 0.01f, s, col)

        // thinking dots
        if (thinkAmt > 0.02f) {
            p.style = Paint.Style.FILL
            p.color = col
            for (i in 0..2) {
                val bounce = sin(time * 6f - i * 0.8f).coerceAtLeast(0f)
                p.alpha = (255 * thinkAmt).toInt()
                canvas.drawCircle((i - 1) * s * 0.085f, -ph / 2 - s * 0.075f - bounce * s * 0.03f, s * 0.018f, p)
            }
        }

        drawBars(canvas, s, ph, col)
        drawZ(canvas, s, ph)
        drawSparks(canvas, s)
        canvas.restore()
    }

    private fun drawAntenna(c: Canvas, s: Float, ph: Float, col: Int) {
        val x = s * 0.22f
        val top = -ph / 2
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.01f
        p.color = Color.rgb(154, 166, 184)
        p.alpha = 255
        c.drawLine(x, top, x, top - s * 0.07f, p)
        p.strokeCap = Paint.Cap.BUTT
        val pulse = if (mode == Mode.LISTENING) sin(time * 6f) else sin(time * 2f) * 0.5f
        val r = s * 0.02f * (1f + 0.25f * pulse)
        p.style = Paint.Style.FILL
        p.color = col
        p.alpha = 50
        c.drawCircle(x, top - s * 0.085f, r * 2.1f, p)
        p.alpha = 255
        c.drawCircle(x, top - s * 0.085f, r, p)
    }

    private fun drawBrow(c: Canvas, side: Int, ex: Float, by: Float, s: Float, col: Int) {
        val hw = s * 0.07f
        val lift = browLift - side * browAsym
        val y = by - lift * s * 0.035f
        val innerX = ex - side * hw
        val outerX = ex + side * hw
        val yInner = y + browTilt * s * 0.022f
        val yOuter = y - browTilt * s * 0.022f
        path.reset()
        path.moveTo(outerX, yOuter)
        path.quadTo(ex, y - s * 0.008f, innerX, yInner)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.022f
        p.color = col
        p.alpha = 190
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun drawEye(c: Canvas, ex: Float, ey: Float, w: Float, h: Float, s: Float, col: Int) {
        val openAmt = 1f - happy
        if (openAmt > 0.02f) {
            val r = min(w, h) * 0.45f
            p.style = Paint.Style.FILL
            p.color = col
            for (i in 3 downTo 1) {          // soft glow
                val g = i * s * 0.012f
                rect.set(ex - w / 2 - g, ey - h / 2 - g, ex + w / 2 + g, ey + h / 2 + g)
                p.alpha = (32 * openAmt).toInt()
                c.drawRoundRect(rect, r + g, r + g, p)
            }
            rect.set(ex - w / 2, ey - h / 2, ex + w / 2, ey + h / 2)
            p.alpha = (255 * openAmt).toInt()
            c.drawRoundRect(rect, r, r, p)
            if (h > s * 0.1f) {              // highlight
                p.color = Color.WHITE
                p.alpha = (200 * openAmt).toInt()
                c.drawCircle(ex - w * 0.18f, ey - h * 0.22f, w * 0.09f, p)
            }
        }
        if (happy > 0.02f) {                  // ^ ^ eyes
            val aw = s * 0.14f
            rect.set(ex - aw / 2, ey - aw * 0.35f, ex + aw / 2, ey + aw * 0.65f)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.color = col
            p.strokeWidth = s * 0.07f
            p.alpha = (40 * happy).toInt()
            c.drawArc(rect, 200f, 140f, false, p)
            p.strokeWidth = s * 0.042f
            p.alpha = (255 * happy).toInt()
            c.drawArc(rect, 200f, 140f, false, p)
            p.strokeCap = Paint.Cap.BUTT
        }
    }

    private fun drawMouth(c: Canvas, mx: Float, my: Float, s: Float, col: Int) {
        val mw = s * 0.24f
        val fillAlpha = (open * 8f).coerceIn(0f, 1f)
        val lineAlpha = 1f - fillAlpha

        if (lineAlpha > 0.02f) {              // smile / frown line
            path.reset()
            path.moveTo(mx - mw / 2, my)
            path.quadTo(mx, my + curve * s * 0.12f, mx + mw / 2, my)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.color = col
            p.strokeWidth = s * 0.05f
            p.alpha = (40 * lineAlpha).toInt()
            c.drawPath(path, p)
            p.strokeWidth = s * 0.028f
            p.alpha = (255 * lineAlpha).toInt()
            c.drawPath(path, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        if (fillAlpha > 0.02f) {              // open mouth
            val h = s * 0.03f + open * s * 0.12f
            val w = mw * (0.55f + 0.45f * (1f - open * 0.6f))
            p.style = Paint.Style.FILL
            p.color = col
            rect.set(mx - w / 2 - s * 0.012f, my - h / 2 - s * 0.012f, mx + w / 2 + s * 0.012f, my + h / 2 + s * 0.012f)
            p.alpha = (40 * fillAlpha).toInt()
            c.drawRoundRect(rect, h, h, p)
            rect.set(mx - w / 2, my - h / 2, mx + w / 2, my + h / 2)
            p.alpha = (255 * fillAlpha).toInt()
            c.drawRoundRect(rect, h / 2, h / 2, p)
        }
    }

    /** Sound bars under the face while listening / speaking. */
    private fun drawBars(c: Canvas, s: Float, ph: Float, col: Int) {
        if (barsAmt < 0.02f) return
        val n = 11
        val y = ph / 2 + s * 0.085f
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.014f
        p.color = col
        for (i in 0 until n) {
            val amp = if (mode == Mode.SPEAKING) abs(sin(time * 8f + i * 0.7f) * sin(time * 3f + i))
            else smoothLevel * (0.35f + 0.65f * abs(sin(time * 7f + i * 0.9f)))
            val half = s * 0.006f + s * 0.05f * barsAmt * amp
            val x = (i - (n - 1) / 2f) * s * 0.034f
            p.alpha = (200 * barsAmt).toInt()
            c.drawLine(x, y - half, x, y + half, p)
        }
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun drawZ(c: Canvas, s: Float, ph: Float) {
        if (sleepAmt < 0.05f) return
        p.style = Paint.Style.FILL
        p.color = Color.rgb(120, 134, 156)
        for (k in 0..2) {
            val phase = (time * 0.4f + k / 3f) % 1f
            p.textSize = s * 0.06f * (1f + k * 0.35f)
            p.alpha = (sin(PI.toFloat() * phase) * 200f * sleepAmt).toInt().coerceIn(0, 255)
            c.drawText("z", s * 0.26f + phase * s * 0.12f, -ph / 2 + s * 0.02f - phase * s * 0.14f, p)
        }
    }

    private fun drawSparks(c: Canvas, s: Float) {
        if (sparks.isEmpty()) return
        p.style = Paint.Style.FILL
        for (k in sparks) {
            val r = k.size * s
            val x = k.x * s
            val y = k.y * s
            path.reset()
            path.moveTo(x, y - r * 1.6f)
            path.lineTo(x + r * 0.6f, y)
            path.lineTo(x, y + r * 1.6f)
            path.lineTo(x - r * 0.6f, y)
            path.close()
            p.color = k.color
            p.alpha = (k.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawPath(path, p)
        }
    }

    // ---------- touch: eyes follow the finger, tap = onTap ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        touchGx = ((e.x / width.coerceAtLeast(1)) - 0.5f).times(2f).coerceIn(-1f, 1f)
        touchGy = ((e.y / height.coerceAtLeast(1)) - 0.5f).times(2f).coerceIn(-1f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                downX = e.x; downY = e.y
                if (mode == Mode.SLEEP) mode = Mode.IDLE
                return true
            }
            MotionEvent.ACTION_MOVE -> return true
            MotionEvent.ACTION_UP -> {
                touching = false
                if (hypot(e.x - downX, e.y - downY) < slop * 2) {
                    onTap?.invoke()
                    performClick()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                touching = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()
}
