package com.amirjon.smarthome

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Talks to the SinricPro REST API (commands) and SSE stream (live events). */
class SinricClient(private val prefs: Prefs) {

    private val api = "https://api.sinric.pro/api/v1"
    private val sseUrl = "https://sse.sinric.pro/sse/stream"

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val sseHttp = http.newBuilder()
        .readTimeout(0, TimeUnit.SECONDS)      // stream stays open
        .build()

    /** Turn a switch on/off. Returns true if SinricPro accepted (queued) the command. */
    suspend fun setPower(deviceId: String, on: Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject()
                .put("type", "request")
                .put("action", "setPowerState")
                .put("value", JSONObject().put("state", if (on) "On" else "Off").toString())
                .toString()
                .toRequestBody("application/json".toMediaType())
            val req = Request.Builder()
                .url("$api/devices/$deviceId/action")
                .header("X-SINRIC-API-KEY", prefs.sinricKey)
                .post(body)
                .build()
            http.newCall(req).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    /** Best-effort fetch of one device; used to pick up an initial value. */
    suspend fun getDevice(deviceId: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$api/devices/$deviceId")
                .header("X-SINRIC-API-KEY", prefs.sinricKey)
                .build()
            http.newCall(req).execute().use { r ->
                if (r.isSuccessful) JSONObject(r.body?.string() ?: "{}") else null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Listens to the live event stream until the coroutine is cancelled,
     * reconnecting automatically. [onStatus] reports connected/disconnected.
     */
    suspend fun listen(onStatus: (Boolean) -> Unit, onEvent: (JSONObject) -> Unit) {
        var wait = 2000L
        while (currentCoroutineContext().isActive) {
            if (prefs.sinricKey.isBlank()) {
                onStatus(false); delay(3000); continue
            }
            withContext(Dispatchers.IO) {
                val call = sseHttp.newCall(
                    Request.Builder()
                        .url(sseUrl)
                        .header("X-SINRIC-API-KEY", prefs.sinricKey)
                        .header("Accept", "text/event-stream")
                        .build()
                )
                currentCoroutineContext().job.invokeOnCompletion { call.cancel() }
                try {
                    call.execute().use { resp ->
                        if (!resp.isSuccessful) return@use
                        onStatus(true)
                        wait = 2000L
                        val src = resp.body!!.source()
                        while (!src.exhausted()) {
                            val line = src.readUtf8Line() ?: break
                            if (line.startsWith("data:")) {
                                val json = line.removePrefix("data:").trim()
                                if (json.startsWith("{")) {
                                    try { onEvent(JSONObject(json)) } catch (_: Exception) {}
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                }
                onStatus(false)
            }
            delay(wait)
            wait = (wait * 2).coerceAtMost(30000L)
        }
    }

    companion object {
        /** Recursively find the first value stored under [key]; also opens JSON strings. */
        fun find(node: Any?, key: String): Any? {
            when (node) {
                is JSONObject -> {
                    if (node.has(key)) return node.get(key)
                    for (k in node.keys()) find(node.get(k), key)?.let { return it }
                }
                is JSONArray -> for (i in 0 until node.length()) find(node.get(i), key)?.let { return it }
                is String -> if (node.startsWith("{")) {
                    try { return find(JSONObject(node), key) } catch (_: Exception) {}
                }
            }
            return null
        }

        fun number(node: Any?, key: String): Double? =
            when (val v = find(node, key)) {
                is Number -> v.toDouble()
                is String -> v.toDoubleOrNull()
                else -> null
            }
    }
}
